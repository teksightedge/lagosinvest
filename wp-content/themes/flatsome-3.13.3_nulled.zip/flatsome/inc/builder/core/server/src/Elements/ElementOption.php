<?php

class UX_Builder_Shortcode_Option extends UX_Builder_Option
{
    // ...
}
